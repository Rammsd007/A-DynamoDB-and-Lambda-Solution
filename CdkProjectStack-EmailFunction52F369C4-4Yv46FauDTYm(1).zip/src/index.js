const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);
const sesClient = new SESClient({});

exports.handler = async (event) => {
  try {
    const params = {
      TableName: process.env.TABLE_NAME,
      Limit: 10,
      ScanIndexForward: false,
    };

    const result = await docClient.send(new ScanCommand(params));
    const emailContent = formatEmailContent(result.Items);

    const emailParams = {
      Source: 'ramachands6858@gmail.com',
      Destination: {
        ToAddresses: [process.env.RECIPIENT_EMAIL],
      },
      Message: {
        Subject: {
          Data: 'Latest User Records',
        },
        Body: {
          Text: {
            Data: emailContent,
          },
        },
      },
    };

    await sesClient.send(new SendEmailCommand(emailParams));

    return {
      statusCode: 200,
      body: 'Email sent successfully',
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: error.message,
    };
  }
};

function formatEmailContent(items) {
  return items
    .map(item => `User ID: ${item.userId}\nTimestamp: ${new Date(item.timestamp).toISOString()}\n`)
    .join('\n');
}